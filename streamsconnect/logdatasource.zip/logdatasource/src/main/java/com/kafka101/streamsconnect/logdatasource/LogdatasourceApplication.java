package com.kafka101.streamsconnect.logdatasource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogdatasourceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogdatasourceApplication.class, args);
	}

}
