package com.kafka101.streamsconnect.logdatasource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogdatasourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
