package com.kafka101.SchemaRegistryServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchemaRegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
